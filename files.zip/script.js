// ========================================
// CHOTANA VETERINARY HOSPITAL - JAVASCRIPT
// Language Switcher - Simple & Reliable
// ========================================

// Language Management
function setLanguage(lang) {
    // Set language on body
    document.body.setAttribute('data-lang', lang);

    // Update active button
    const buttons = document.querySelectorAll('.language-selector button');
    buttons.forEach(btn => {
        btn.classList.remove('active');
        if (btn.getAttribute('data-lang') === lang) {
            btn.classList.add('active');
        }
    });

    // Save language preference
    localStorage.setItem('preferredLanguage', lang);

    // Update HTML lang attribute
    document.documentElement.lang = lang;
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {

    // Default to Thai
    let defaultLang = 'th';

    // Check saved preference
    const savedLang = localStorage.getItem('preferredLanguage');
    if (savedLang) {
        defaultLang = savedLang;
    }

    // Set the language immediately
    setLanguage(defaultLang);

    // Smooth scroll for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            const href = this.getAttribute('href');
            if (href !== '#') {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth', block: 'start' });
                }
            }
        });
    });
});

// Form submission
function submitForm() {
    const name = document.getElementById('name').value;
    const phone = document.getElementById('phone').value;
    if (!name || !phone) {
        alert('Please enter your name and phone number.\nกรุณากรอกชื่อและเบอร์โทรศัพท์');
        return;
    }
    alert('Thank you! We will contact you shortly.\nขอบคุณ! เราจะติดต่อคุณเร็วๆ นี้\n谢谢！我们将尽快与您联系。');
    document.getElementById('name').value = '';
    document.getElementById('phone').value = '';
    document.getElementById('email').value = '';
    if (document.getElementById('message')) {
        document.getElementById('message').value = '';
    }
}

console.log('🐕 Chotana Veterinary Hospital - Website Loaded 🐈');
